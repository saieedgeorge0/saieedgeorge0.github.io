#Poly-Art-Profile-Pictures
These are low poly art images created using photoshop.
