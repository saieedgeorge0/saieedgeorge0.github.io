#Poly-Art-Profile-Picture
This is a low poly art image created (for another person) using photoshop. The original is original.jpg, and the low poly version is lowpoly.jpg.
