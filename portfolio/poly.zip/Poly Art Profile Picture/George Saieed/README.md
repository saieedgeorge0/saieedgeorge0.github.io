#Poly-Art-Profile-Picture
This is a low poly art image created using photoshop. The original is original.jpg, and the low poly version is lowpoly.jpg.
